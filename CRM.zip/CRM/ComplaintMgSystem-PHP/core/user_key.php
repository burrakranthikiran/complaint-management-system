<?php
if(isset($_SESSION['email'])===false){
    header("location:error.php");
}
?>
