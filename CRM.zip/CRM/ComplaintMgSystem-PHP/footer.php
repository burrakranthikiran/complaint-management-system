<footer>
  <div class="foonav">
      <a href="blog/blog.php">Blog </a> &nbsp;&nbsp;|
      <a href="blog/documentation.php">Documentaion</a>

  </div>

  &copy <?php echo date("Y"); ?>
  <?php echo $web_name; ?>

</footer>
